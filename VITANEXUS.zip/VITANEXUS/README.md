# VitaNexus — Proyecto Final (Programacion 5, UNIAJC)

**Sistema de gestion para un hogar gerontologico.** Conecta la gestion del cuidado
con la comunicacion controlada hacia las familias.

- **Integrantes:** Jose Elias Carabali Montenegro · Fernando de Jesus Gutierrez Caballero
- **Stack:** PostgreSQL · Node.js / Express (API REST) · Next.js (frontend, fase posterior)

## Estructura del repositorio

```
vitanexus/
├── backend/        API REST en Node.js + Express (arquitectura por capas)
├── database/       Script SQL del modelo relacional (18 tablas) + datos de prueba
├── docs/           Guia completa e informes (PDF) de ambos talleres
├── mockups/        Diagrama ER y bocetos de pantalla por rol
└── postman/        Coleccion de pruebas de la API
```

## Puesta en marcha rapida

1. **Base de datos** (requiere PostgreSQL):
   ```bash
   psql -U postgres -c "CREATE DATABASE vitanexus;"
   psql -U postgres -d vitanexus -f database/vitanexus.sql
   ```
2. **Backend**:
   ```bash
   cd backend
   npm install
   copy .env.example .env      REM Windows  (usa: cp en Linux/Mac)
   REM edita .env con tu password de PostgreSQL
   npm run dev
   ```
   La API queda en http://localhost:3000

3. **Probar**: importa `postman/VitaNexus.postman_collection.json` en Postman,
   o abre http://localhost:3000/api/residentes en el navegador.

El paso a paso detallado esta en `docs/VitaNexus_Guia_Completa.pdf`.
