// Capa de controladores: recibe la peticion, responde con el codigo HTTP y JSON.
const model = require('../models/signosVitales.model');

async function listar(req, res, next) {
  try {
    const data = await model.findAll();
    res.status(200).json(data);
  } catch (e) { next(e); }
}

async function obtener(req, res, next) {
  try {
    const row = await model.findById(req.params.id);
    if (!row) return res.status(404).json({ error: 'Registro de signos vitales no encontrado' });
    res.status(200).json(row);
  } catch (e) { next(e); }
}

async function crear(req, res, next) {
  try {
    const faltan = (!req.body.residente_id || !req.body.usuario_id);
    if (faltan) return res.status(400).json({ error: 'Faltan campos obligatorios: residente_id, usuario_id' });
    const row = await model.create(req.body);
    res.status(201).json(row);
  } catch (e) { next(e); }
}

async function actualizar(req, res, next) {
  try {
    const row = await model.update(req.params.id, req.body);
    if (!row) return res.status(404).json({ error: 'Registro de signos vitales no encontrado' });
    res.status(200).json(row);
  } catch (e) { next(e); }
}

async function eliminar(req, res, next) {
  try {
    const row = await model.remove(req.params.id);
    if (!row) return res.status(404).json({ error: 'Registro de signos vitales no encontrado' });
    res.status(200).json({ mensaje: 'Registro de signos vitales eliminado', id: row.id });
  } catch (e) { next(e); }
}

module.exports = { listar, obtener, crear, actualizar, eliminar };
