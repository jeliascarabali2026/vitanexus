// Capa de controladores: recibe la peticion, responde con el codigo HTTP y JSON.
const model = require('../models/solicitudesVisita.model');

async function listar(req, res, next) {
  try {
    const data = await model.findAll();
    res.status(200).json(data);
  } catch (e) { next(e); }
}

async function obtener(req, res, next) {
  try {
    const row = await model.findById(req.params.id);
    if (!row) return res.status(404).json({ error: 'Solicitud de visita no encontrado' });
    res.status(200).json(row);
  } catch (e) { next(e); }
}

async function crear(req, res, next) {
  try {
    const faltan = (!req.body.usuario_id || !req.body.residente_id || !req.body.fecha_visita || !req.body.hora_inicio);
    if (faltan) return res.status(400).json({ error: 'Faltan campos obligatorios: usuario_id, residente_id, fecha_visita, hora_inicio' });
    const row = await model.create(req.body);
    res.status(201).json(row);
  } catch (e) { next(e); }
}

async function actualizar(req, res, next) {
  try {
    const row = await model.update(req.params.id, req.body);
    if (!row) return res.status(404).json({ error: 'Solicitud de visita no encontrado' });
    res.status(200).json(row);
  } catch (e) { next(e); }
}

async function eliminar(req, res, next) {
  try {
    const row = await model.remove(req.params.id);
    if (!row) return res.status(404).json({ error: 'Solicitud de visita no encontrado' });
    res.status(200).json({ mensaje: 'Solicitud de visita eliminado', id: row.id });
  } catch (e) { next(e); }
}

module.exports = { listar, obtener, crear, actualizar, eliminar };
