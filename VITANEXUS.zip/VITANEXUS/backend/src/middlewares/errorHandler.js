// Capa de middlewares: manejo central de errores y rutas no encontradas.

// 404: ninguna ruta coincidio.
function notFound(req, res, next) {
  res.status(404).json({ error: 'Ruta no encontrada', ruta: req.originalUrl });
}

// Manejador central de errores. Traduce errores de PostgreSQL a codigos HTTP claros.
function errorHandler(err, req, res, next) { // eslint-disable-line no-unused-vars
  console.error('[ERROR]', err.message);
  switch (err.code) {
    case '23505': // unique_violation
      return res.status(400).json({ error: 'Registro duplicado', detalle: err.detail });
    case '23503': // foreign_key_violation
      return res.status(400).json({ error: 'Referencia invalida (llave foranea)', detalle: err.detail });
    case '23514': // check_violation
      return res.status(400).json({ error: 'Dato fuera de los valores permitidos', detalle: err.detail });
    case '23502': // not_null_violation
      return res.status(400).json({ error: 'Falta un campo obligatorio', detalle: err.column });
    case '22P02': // invalid_text_representation (ej. id no numerico)
      return res.status(400).json({ error: 'Formato de dato invalido', detalle: err.message });
    default:
      return res.status(500).json({ error: 'Error interno del servidor', detalle: err.message });
  }
}

module.exports = { notFound, errorHandler };
