// Capa de modelo (acceso a datos): consultas SQL parametrizadas a PostgreSQL.
const { pool } = require('../config/db');

const COLS = 'id, usuario_id, residente_id, fecha_visita, hora_inicio, hora_fin, estado, aprobada_por, motivo, creado_en';
const TABLE = 'solicitudes_visita';

async function findAll() {
  const { rows } = await pool.query('SELECT ' + COLS + ' FROM ' + TABLE + ' ORDER BY id');
  return rows;
}

async function findById(id) {
  const { rows } = await pool.query('SELECT ' + COLS + ' FROM ' + TABLE + ' WHERE id = $1', [id]);
  return rows[0];
}

async function create(d) {
  const { rows } = await pool.query(
    `INSERT INTO solicitudes_visita (usuario_id, residente_id, fecha_visita, hora_inicio, hora_fin, estado, aprobada_por, motivo)
     VALUES ($1,$2,$3,$4,$5,COALESCE($6,'pendiente'),$7,$8)
     RETURNING ${COLS}`,
    [d.usuario_id, d.residente_id, d.fecha_visita, d.hora_inicio, d.hora_fin, d.estado, d.aprobada_por, d.motivo]
  );
  return rows[0];
}

async function update(id, d) {
  const { rows } = await pool.query(
    `UPDATE solicitudes_visita SET
       usuario_id = COALESCE($2, usuario_id),
       residente_id = COALESCE($3, residente_id),
       fecha_visita = COALESCE($4, fecha_visita),
       hora_inicio = COALESCE($5, hora_inicio),
       hora_fin = COALESCE($6, hora_fin),
       estado = COALESCE($7, estado),
       aprobada_por = COALESCE($8, aprobada_por),
       motivo = COALESCE($9, motivo)
     WHERE id = $1
     RETURNING ${COLS}`,
    [id, d.usuario_id, d.residente_id, d.fecha_visita, d.hora_inicio, d.hora_fin, d.estado, d.aprobada_por, d.motivo]
  );
  return rows[0];
}

async function remove(id) {
  const { rows } = await pool.query('DELETE FROM ' + TABLE + ' WHERE id = $1 RETURNING id', [id]);
  return rows[0];
}

module.exports = { findAll, findById, create, update, remove };
