// Capa de modelo (acceso a datos): consultas SQL parametrizadas a PostgreSQL.
const { pool } = require('../config/db');

const COLS = 'id, documento, nombres, apellidos, fecha_nacimiento, sexo, eps, nivel_dependencia, movilidad, enfermedades_cronicas, alergias, contacto_emergencia_nombre, contacto_emergencia_telefono, fecha_ingreso, activo, creado_en';
const TABLE = 'residentes';

async function findAll() {
  const { rows } = await pool.query('SELECT ' + COLS + ' FROM ' + TABLE + ' ORDER BY id');
  return rows;
}

async function findById(id) {
  const { rows } = await pool.query('SELECT ' + COLS + ' FROM ' + TABLE + ' WHERE id = $1', [id]);
  return rows[0];
}

async function create(d) {
  const { rows } = await pool.query(
    `INSERT INTO residentes (documento, nombres, apellidos, fecha_nacimiento, sexo, eps, nivel_dependencia, movilidad,
       enfermedades_cronicas, alergias, contacto_emergencia_nombre, contacto_emergencia_telefono, fecha_ingreso)
     VALUES ($1,$2,$3,$4,$5,$6,COALESCE($7,'autonomo'),$8,$9,$10,$11,$12,COALESCE($13,CURRENT_DATE))
     RETURNING ${COLS}`,
    [d.documento, d.nombres, d.apellidos, d.fecha_nacimiento, d.sexo, d.eps, d.nivel_dependencia, d.movilidad,
     d.enfermedades_cronicas, d.alergias, d.contacto_emergencia_nombre, d.contacto_emergencia_telefono, d.fecha_ingreso]
  );
  return rows[0];
}

async function update(id, d) {
  const { rows } = await pool.query(
    `UPDATE residentes SET
       documento = COALESCE($2, documento),
       nombres = COALESCE($3, nombres),
       apellidos = COALESCE($4, apellidos),
       fecha_nacimiento = COALESCE($5, fecha_nacimiento),
       sexo = COALESCE($6, sexo),
       eps = COALESCE($7, eps),
       nivel_dependencia = COALESCE($8, nivel_dependencia),
       movilidad = COALESCE($9, movilidad),
       enfermedades_cronicas = COALESCE($10, enfermedades_cronicas),
       alergias = COALESCE($11, alergias),
       contacto_emergencia_nombre = COALESCE($12, contacto_emergencia_nombre),
       contacto_emergencia_telefono = COALESCE($13, contacto_emergencia_telefono),
       fecha_ingreso = COALESCE($14, fecha_ingreso),
       activo = COALESCE($15, activo)
     WHERE id = $1
     RETURNING ${COLS}`,
    [id, d.documento, d.nombres, d.apellidos, d.fecha_nacimiento, d.sexo, d.eps, d.nivel_dependencia,
     d.movilidad, d.enfermedades_cronicas, d.alergias, d.contacto_emergencia_nombre, d.contacto_emergencia_telefono,
     d.fecha_ingreso, d.activo]
  );
  return rows[0];
}

async function remove(id) {
  const { rows } = await pool.query('DELETE FROM ' + TABLE + ' WHERE id = $1 RETURNING id', [id]);
  return rows[0];
}

module.exports = { findAll, findById, create, update, remove };
