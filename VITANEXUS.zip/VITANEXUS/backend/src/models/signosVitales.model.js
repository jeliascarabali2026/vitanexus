// Capa de modelo (acceso a datos): consultas SQL parametrizadas a PostgreSQL.
const { pool } = require('../config/db');

const COLS = 'id, residente_id, usuario_id, fecha_registro, presion_sistolica, presion_diastolica, frecuencia_cardiaca, frecuencia_respiratoria, temperatura, saturacion_oxigeno, glucometria, peso, observacion, creado_en';
const TABLE = 'signos_vitales';

async function findAll() {
  const { rows } = await pool.query('SELECT ' + COLS + ' FROM ' + TABLE + ' ORDER BY id');
  return rows;
}

async function findById(id) {
  const { rows } = await pool.query('SELECT ' + COLS + ' FROM ' + TABLE + ' WHERE id = $1', [id]);
  return rows[0];
}

async function create(d) {
  const { rows } = await pool.query(
    `INSERT INTO signos_vitales (residente_id, usuario_id, presion_sistolica, presion_diastolica, frecuencia_cardiaca,
       frecuencia_respiratoria, temperatura, saturacion_oxigeno, glucometria, peso, observacion)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
     RETURNING ${COLS}`,
    [d.residente_id, d.usuario_id, d.presion_sistolica, d.presion_diastolica, d.frecuencia_cardiaca,
     d.frecuencia_respiratoria, d.temperatura, d.saturacion_oxigeno, d.glucometria, d.peso, d.observacion]
  );
  return rows[0];
}

async function update(id, d) {
  const { rows } = await pool.query(
    `UPDATE signos_vitales SET
       residente_id = COALESCE($2, residente_id),
       usuario_id = COALESCE($3, usuario_id),
       presion_sistolica = COALESCE($4, presion_sistolica),
       presion_diastolica = COALESCE($5, presion_diastolica),
       frecuencia_cardiaca = COALESCE($6, frecuencia_cardiaca),
       frecuencia_respiratoria = COALESCE($7, frecuencia_respiratoria),
       temperatura = COALESCE($8, temperatura),
       saturacion_oxigeno = COALESCE($9, saturacion_oxigeno),
       glucometria = COALESCE($10, glucometria),
       peso = COALESCE($11, peso),
       observacion = COALESCE($12, observacion)
     WHERE id = $1
     RETURNING ${COLS}`,
    [id, d.residente_id, d.usuario_id, d.presion_sistolica, d.presion_diastolica, d.frecuencia_cardiaca,
     d.frecuencia_respiratoria, d.temperatura, d.saturacion_oxigeno, d.glucometria, d.peso, d.observacion]
  );
  return rows[0];
}

async function remove(id) {
  const { rows } = await pool.query('DELETE FROM ' + TABLE + ' WHERE id = $1 RETURNING id', [id]);
  return rows[0];
}

module.exports = { findAll, findById, create, update, remove };
