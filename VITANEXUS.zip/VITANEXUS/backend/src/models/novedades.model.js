// Capa de modelo (acceso a datos): consultas SQL parametrizadas a PostgreSQL.
const { pool } = require('../config/db');

const COLS = 'id, residente_id, usuario_id, fecha_registro, tipo, descripcion, gravedad, notificar_familiar, creado_en';
const TABLE = 'novedades';

async function findAll() {
  const { rows } = await pool.query('SELECT ' + COLS + ' FROM ' + TABLE + ' ORDER BY id');
  return rows;
}

async function findById(id) {
  const { rows } = await pool.query('SELECT ' + COLS + ' FROM ' + TABLE + ' WHERE id = $1', [id]);
  return rows[0];
}

async function create(d) {
  const { rows } = await pool.query(
    `INSERT INTO novedades (residente_id, usuario_id, tipo, descripcion, gravedad, notificar_familiar)
     VALUES ($1,$2,$3,$4,COALESCE($5,'informativa'),COALESCE($6,false))
     RETURNING ${COLS}`,
    [d.residente_id, d.usuario_id, d.tipo, d.descripcion, d.gravedad, d.notificar_familiar]
  );
  return rows[0];
}

async function update(id, d) {
  const { rows } = await pool.query(
    `UPDATE novedades SET
       residente_id = COALESCE($2, residente_id),
       usuario_id = COALESCE($3, usuario_id),
       tipo = COALESCE($4, tipo),
       descripcion = COALESCE($5, descripcion),
       gravedad = COALESCE($6, gravedad),
       notificar_familiar = COALESCE($7, notificar_familiar)
     WHERE id = $1
     RETURNING ${COLS}`,
    [id, d.residente_id, d.usuario_id, d.tipo, d.descripcion, d.gravedad, d.notificar_familiar]
  );
  return rows[0];
}

async function remove(id) {
  const { rows } = await pool.query('DELETE FROM ' + TABLE + ' WHERE id = $1 RETURNING id', [id]);
  return rows[0];
}

module.exports = { findAll, findById, create, update, remove };
