// Capa de rutas: monta cada recurso del CRUD bajo /api.
const router = require('express').Router();

router.use('/residentes', require('./residentes.routes'));
router.use('/signos-vitales', require('./signosVitales.routes'));
router.use('/novedades', require('./novedades.routes'));
router.use('/solicitudes-visita', require('./solicitudesVisita.routes'));

module.exports = router;
