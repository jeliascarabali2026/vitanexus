// Capa de rutas del recurso.
const router = require('express').Router();
const c = require('../controllers/solicitudesVisita.controller');

router.get('/', c.listar);        // Consultar todos
router.get('/:id', c.obtener);    // Consultar uno
router.post('/', c.crear);        // Crear
router.put('/:id', c.actualizar); // Actualizar
router.delete('/:id', c.eliminar);// Eliminar

module.exports = router;
