// Configuracion de la aplicacion Express (middlewares + rutas).
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const apiRoutes = require('./routes');
const { notFound, errorHandler } = require('./middlewares/errorHandler');

const app = express();

// Middlewares globales
app.use(cors());               // permite que el frontend consuma la API
app.use(express.json());       // parsea cuerpos JSON
app.use(morgan('dev'));        // log de peticiones en consola

// Ruta raiz: estado de la API
app.get('/', (req, res) => {
  res.json({ api: 'VitaNexus', version: '1.0.0', estado: 'activo' });
});

// Todas las rutas del CRUD cuelgan de /api
app.use('/api', apiRoutes);

// Manejo de errores (siempre al final)
app.use(notFound);
app.use(errorHandler);

module.exports = app;
