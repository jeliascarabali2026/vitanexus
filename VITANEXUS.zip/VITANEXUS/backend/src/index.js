// Punto de entrada: carga variables de entorno, arranca el servidor.
require('dotenv').config();
const app = require('./app');
const { pool } = require('./config/db');

const PORT = process.env.PORT || 3000;

(async () => {
  try {
    await pool.query('SELECT 1');
    console.log('\u2713 Conexion a PostgreSQL exitosa (base: ' + (process.env.DB_NAME || 'vitanexus') + ')');
  } catch (e) {
    console.error('\u2717 No se pudo conectar a PostgreSQL:', e.message);
  }
  app.listen(PORT, () => {
    console.log('VitaNexus API escuchando en http://localhost:' + PORT);
  });
})();
