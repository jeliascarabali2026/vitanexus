# VitaNexus — Backend (API REST)

API REST en Node.js + Express con PostgreSQL. Arquitectura por capas.

## Requisitos
- Node.js LTS (18+). Probado en Node 22.
- PostgreSQL con la base `vitanexus` creada (ver `../database/vitanexus.sql`).

## Instalacion
```bash
npm install
cp .env.example .env     # en Windows: copy .env.example .env
# edita .env con las credenciales reales de PostgreSQL
```

## Ejecucion
```bash
npm run dev     # modo desarrollo (recarga automatica)
npm start       # modo normal
```
Servidor en http://localhost:3000

## Arquitectura por capas
```
src/
├── index.js                # arranque: carga .env y levanta el servidor
├── app.js                  # configuracion de Express (middlewares + rutas)
├── config/db.js            # pool de conexion a PostgreSQL (desde .env)
├── routes/                 # define las rutas (endpoints) de cada recurso
├── controllers/            # recibe la peticion, responde codigo HTTP + JSON
├── models/                 # consultas SQL parametrizadas (acceso a datos)
└── middlewares/            # manejo central de errores y 404
```

## Recursos (CRUD completo)
| Recurso            | Ruta base                 |
|--------------------|---------------------------|
| Residentes         | /api/residentes           |
| Signos vitales     | /api/signos-vitales       |
| Novedades          | /api/novedades            |
| Solicitudes visita | /api/solicitudes-visita   |

Cada recurso expone: `GET /` (listar), `GET /:id` (uno), `POST /` (crear),
`PUT /:id` (actualizar), `DELETE /:id` (eliminar).

## Variables de entorno (.env)
| Variable     | Descripcion                 | Ejemplo     |
|--------------|-----------------------------|-------------|
| PORT         | Puerto del servidor         | 3000        |
| DB_HOST      | Host de PostgreSQL          | localhost   |
| DB_PORT      | Puerto de PostgreSQL        | 5432        |
| DB_USER      | Usuario                     | postgres    |
| DB_PASSWORD  | Contrasena                  | (tu clave)  |
| DB_NAME      | Base de datos               | vitanexus   |

> Nota: esta entrega (Tarea 2) **no incluye autenticacion/JWT**, segun la guia.
